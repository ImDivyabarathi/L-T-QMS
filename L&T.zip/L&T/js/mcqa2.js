function validate() {
        var radiob = document.getElementsByName("radiob");
        var selected;
        var val="four";

        for(var i = 0; i < radiob.length; i++) {
        if(radiob[i].checked){
        selected = radiob[i].value;
	    if(selected == val){
	       alert("Correct answer! The starting letter is different when Pronuncing!");
		 }
		 else{if(selected != val){
	       alert("Try again");
		 }
       }
	   }		   
    }
	}