$(document).ready(function(){
    $(".start_button").click(function(){
        $(".first_page,.slide_part").hide();
        $(".second_page").show();
        $("body").css({"background":"url(assets/images/bg.png)"});
        $(".slide_change_part").css({"display": "none"});
    });
    $(".module_lists1,.module_lists2,.module_lists3").click(function(){
        $(".module_part").hide();
        $(".slide_part").show();
        $("body").css({"background":"url(assets/images/bg.png)"});
        $(".menu_list_item,.footer_list_group,.mobile_menu").css({"pointer-events": "auto","opacity": "1"});
        $(".slide_change_part").css({"display": "block"});
    });
    $("#home,#home1").click(function(){
        $(".slide_part").hide();
        $("#mySidenav").hide();
        $(".module_part").show();
        $(".menu_list_item,.footer_list_group,.mobile_menu").css({"pointer-events": "none","opacity": "0.5"});
        $(".slide_change_part").css({"display": "none"});   
    });
    $('.mobile_menu').click(function (){
        $("#mySidenav").show();
    });
    $('.page1').click(function (){
        $(".slide1").show();
        $(".slide2,.slide3,.slide4,.slide5,.slide6").hide();
        $("#myNav").css({"height": "0"});
        $("#mySidenav").css({"width": "0"});
    });
    $('.page2').click(function (){
        $(".slide2").show();
        $(".slide1,.slide3,.slide4,.slide5,.slide6").hide();
        $("#myNav").css({"height": "0"});
        $("#mySidenav").css({"width": "0"});
    });
    $('.page3').click(function (){
        $(".slide3").show();
        $(".slide2,.slide1,.slide4,.slide5,.slide6").hide();
        $("#myNav").css({"height": "0"});
        $("#mySidenav").css({"width": "0"});
    });
    $('.page4').click(function (){
        $(".slide4").show();
        $(".slide2,.slide3,.slide1,.slide5,.slide6").hide();
        $("#myNav").css({"height": "0"});
        $("#mySidenav").css({"width": "0"});
    });
    $('.page5').click(function (){
        $(".slide5").show();
        $(".slide2,.slide3,.slide1,.slide4,.slide6").hide();
        $("#myNav").css({"height": "0"});
        $("#mySidenav").css({"width": "0"});
    });
    $('.page6').click(function (){
        $(".slide6").show();
        $(".slide2,.slide3,.slide1,.slide4,.slide5").hide();
        $("#myNav").css({"height": "0"});
        $("#mySidenav").css({"width": "0"});
    });
    $('#courses,#courses1').click(function(){
        $(".course_menu,.accordion_course_head").show();
        $(".glossary_menu").hide();
        $(".resource_menu").hide();
        $(".reference_menu").hide();
        $(".help_menu").hide();
    });
    $('#glossary,#glossary1').click(function(){
        $(".glossary_menu").show();
        $(".course_menu,.accordion_course_head").hide();
        $(".resource_menu").hide();
        $(".reference_menu").hide();
        $(".help_menu").hide();
    });
    $('#resource,#resource1').click(function(){
        $(".resource_menu").show();
        $(".course_menu,.accordion_course_head").hide();
        $(".glossary_menu").hide();
        $(".reference_menu").hide();
        $(".help_menu").hide();
    });
    $('#reference,#reference1').click(function(){
        $(".reference_menu").show();
        $(".course_menu,.accordion_course_head").hide();
        $(".glossary_menu").hide();
        $(".resource_menu").hide();
        $(".help_menu").hide();
    });
    $('#help').click(function(){
        $(".help_menu").show();
        $(".reference_menu").hide();
        $(".course_menu,.accordion_course_head").hide();
        $(".glossary_menu").hide();
        $(".resource_menu").hide();
    });
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
});

// play pause
document.getElementById("playPausImg").addEventListener("click", playPause);
function playPause(){
    if($('#playPausImg').hasClass('playClass')){
        $('#playPausImg').attr('src',"assets/images/pause_button.png");
        $('#playPausImg').addClass('pauseClass').removeClass('playClass');
    }
    else{
        $('#playPausImg').attr('src',"assets/images/play_button.png");
        $('#playPausImg').addClass('playClass').removeClass('pauseClass');
    }
}
// mute unmute
document.getElementById("muteUnmuteImg").addEventListener("click", muteUnmute);
function muteUnmute(){
    if($('#muteUnmuteImg').hasClass('muteClass')){
        $('#muteUnmuteImg').attr('src',"assets/images/audio_off_button.png");
        $('#muteUnmuteImg').addClass('unmuteClass').removeClass('muteClass');
    }
    else{
        $('#muteUnmuteImg').attr('src',"assets/images/audio_on_button.png");
        $('#muteUnmuteImg').addClass('muteClass').removeClass('unmuteClass');
    }
}
//module slides
var slideIndex = 1;
showDivs(slideIndex);
function plusDivs(n) {
  showDivs(slideIndex += n);
}
function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("body_part");
  if (n > x.length) {
    slideIndex = 1;
  }
  if (n < 1) {
      slideIndex = x.length;
      }
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
    // console.log(i);
    // i++;
    document.getElementById("pg_no").innerHTML = "Page " + i + " of 5";
  }
  x[slideIndex-1].style.display = "";  
}

// var prev = document.getElementById('prev');
// var next = document.getElementById('next');
// var x = document.getElementsByClassName("body_part");
// if(x > 0){
    
// }

// Accordion
var acc = document.getElementsByClassName("accordion");
var a;
for (a = 0; a < acc.length; a++) {
  acc[a].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight){
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}
// audio
var audio1 = document.getElementById("audio1");
function playPause_btn(){
    return audio1.paused ? audio1.play() : audio1.pause();
};
// Mobile menu overlay
var menuState = 0;
document.getElementById("myBtn").addEventListener("click", open_close);
function open_close() {
   if(menuState === 0){
    menuState = 1;
    document.getElementById("mySidenav").style.width = "100%";
   }
   else {
    menuState = 0;
    document.getElementById("mySidenav").style.width = "0";
   }
}

// Overlay_open_close
var xOpen = document.getElementsByClassName('openOVerlay');
for(let i=0;i<xOpen.length;i++){
    xOpen[i].onclick = function() {
    document.getElementById("myNav").style.height = "100%";
}
}   
var xClose = document.getElementsByClassName('CloseOverlay');
for(let i=0;i<xClose.length;i++){
    xClose[i].onclick = function() {
    document.getElementById("myNav").style.height = "0";
}
}
